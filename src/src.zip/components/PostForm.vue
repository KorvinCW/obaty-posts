<template>
    <div>
        <h1>{{ pageTitle }}</h1>
        <form>
            <div>
                <label for="title">Title</label>
                <input id="title" type="text" v-model="title" />
            </div>
            <div>
                <label for="body">Text</label>
                <textarea id="body" v-model="body"></textarea>
            </div>
            <button @click="submit">
                {{ buttonName }}
            </button>
            <button v-if="isCurrentUsersPost" @click="deletePost">
                Delete
            </button>
            <router-link to="/">Back</router-link>
        </form>
        <PostComments v-if="isEditMode"/>
    </div>
</template>

<script>
import { defineComponent, ref } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { useStore } from 'vuex';

import PostComments from './PostComments.vue';

export default defineComponent({
  components: {
    PostComments
  },
  setup() {
    const store = useStore();
    const route = useRoute();
    const router = useRouter();

    const isEditMode = !!route.params.id;
    const buttonName = isEditMode ? 'Update' : 'Create';
    const pageTitle = isEditMode ? 'Edit post' : 'New post';
    const currentPost = store.getters.getPostById(route.params.id);
    const isCurrentUsersPost = isEditMode && (store.state.post.currentUser.id === currentPost.userId);

    // const postComments = computed(() => store.getters.postComments);

    const title = ref(currentPost?.title || '');
    const body = ref(currentPost?.body || '');

    // onMounted(async () => {
    //   if (isEditMode) {
    //     await store.dispatch('loadPostComments', route.params.id);
    //   }
    // });

    const submit = () => {
        const postData = {
            title: title.value,
            body: body.value,
            id: isEditMode ? Number(route.params.id) : Date.now(),
            userId: currentPost?.userId || store.state.post.currentUser.id,
        };
        const mutationName = isEditMode ? 'updatePost' : 'createPost';
        store.dispatch(mutationName, postData)
        .then(navigateToPosts());
    };

    const deletePost = () => {
        const postId = Number(route.params.id);
        store.dispatch('deletePost', postId)
        .then(navigateToPosts());
    };

    const navigateToPosts = () => router.push('/')

    return { title, body, isEditMode, pageTitle, submit, isCurrentUsersPost, deletePost, buttonName };
  },
});
</script>