<template>
    <ul>
        <li v-for="post of allPosts" :key="post.id">
          <router-link :to="{ name:'post-form', params: {id: post.id} }">
            <div class="content">
              <h2 class="postTitle">{{ post.title }}</h2>
              <p>{{ post.body }}</p>
            </div>
          </router-link>
        </li>
    </ul>
</template>

<script>
import { defineComponent, computed, onMounted } from 'vue';
import { useStore } from 'vuex';

export default defineComponent({
  name: 'AllPosts',
  setup() {
    const store = useStore();
    const allPosts = computed(() => store.getters.allPosts);

    onMounted(async () => {
      if (!store.state.post.postsList.length) {
        await store.dispatch('loadPosts');
      }
      if (!Object.keys(store.state.post.currentUser).length) {
        await store.dispatch('loadUser');
      }
    });

    return { allPosts };
  }
})
</script>
<style scoped>
ul {
  text-align: left;
  list-style-type: none;
}

.content {
  color: #000000;
}
</style>